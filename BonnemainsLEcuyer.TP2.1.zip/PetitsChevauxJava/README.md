# PetitsChevauxJava
Le célèbre jeu des petits chevaux en console Java
